(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1b77ad23._.js",
  "static/chunks/node_modules_next_f06cca34._.js"
],
    source: "dynamic"
});
