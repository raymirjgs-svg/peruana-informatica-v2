(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b8ca2513._.js",
  "static/chunks/node_modules_239055f2._.js",
  "static/chunks/src_app_globals_91e4631d.css"
],
    source: "dynamic"
});
