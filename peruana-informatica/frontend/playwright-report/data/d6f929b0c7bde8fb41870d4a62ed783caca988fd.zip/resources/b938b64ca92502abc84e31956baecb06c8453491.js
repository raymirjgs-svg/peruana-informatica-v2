(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_58715fd1._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_aeda7e45._.js"
],
    source: "dynamic"
});
